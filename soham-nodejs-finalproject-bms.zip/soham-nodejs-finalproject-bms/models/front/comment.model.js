const mongoose = require('mongoose');
const schema = mongoose.Schema;

const comSchema = schema({ 
    message: { type: String, require:true },    
    user_register_id: { type: schema.Types.ObjectId , default : null},
    post_id: { type: schema.Types.ObjectId , default : null},          
    isDeleted: { type: Boolean, enum: [true, false], default: false },
    isStatus: { type: String, enum: ["Active", "Inactive"], default: "Inactive"  }
}, {
    timestamps: true,
    versionKey: false
})

module.exports = mongoose.model('comment', comSchema);