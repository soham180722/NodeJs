const catModel = require("../../models/admin/category.model");
const banModel = require("../../models/admin/banner.model");
const postModel = require("../../models/front/post.model");
const commentModel = require("../../models/front/comment.model");
const faqModel = require("../../models/admin/faq.model");
const mongoose = require('mongoose');
const registerModel = require('../../models/front/register.model');
const contactModel = require('../../models/front/contact.model');
const mailer = require('../../helper/mailer');
const os = require('os'); const fs = require('fs');
const bcrypt = require('bcryptjs');

class HomeController{

    async userAuth(req, res, next){
        try {
            if(!_.isEmpty(req.user)){                   
                next();
            } else { 
                req.flash('error' , 'UnAuthorized UseR .. Please Login')              
                res.redirect('/login');                           
            }

        } catch(err){
            throw(err);
        }
    }

    async home(req, res){ 
        try{ 
            let loginUser ='';
            if(!_.isEmpty(req.user)) {
                loginUser = await registerModel.findOne({ _id : req.user.id });
            } //console.log( req.user);
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            const banDetails = await banModel.find({ isDeleted: false, isStatus: 'Active' });
            const popularityDetails = await postModel.aggregate([
                {
                    $lookup:{
                        from:'user_registers',
                        let : {                           
                            userId : '$user_register_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$userId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    fullname:1,                                   
                                    image:1                                   
                                }
                            }
                        ],
                        as: 'user_details'
                    }
                },
                {
                    $unwind: '$user_details'
                },
                {
                    $lookup:{
                        from:'categories',
                        let : {                           
                            catId : '$category_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$catId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    name:1,                                                                    
                                }
                            }
                        ],
                        as: 'cat_details'
                    }
                },
                {
                    $unwind: '$cat_details'
                },              
                
                {                   
                    $match : { 'isStatus' : 'Active'}                   
                },
                
                {                   
                    $match : { 'isPopular' : true }                   
                }, 

                {
                    $limit : 6
                },

                { 
                    $sort : { createdAt : -1 } 
                },

                {
                    $project:{
                        _id:1,
                        heading:1,
                        post:1,
                        image:1,
                        isStatus:1,
                        isDeleted:1,
                        createdAt:1,
                        'user_details.fullname':1,                       
                        'user_details.image':1,
                        'cat_details.name':1
                    }
                }
            ]);
            const fashionDetails = await postModel.aggregate([
                {
                    $lookup:{
                        from:'user_registers',
                        let : {                           
                            userId : '$user_register_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$userId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    fullname:1,                                   
                                    image:1                                   
                                }
                            }
                        ],
                        as: 'user_details'
                    }
                },
                {
                    $unwind: '$user_details'
                },
                {
                    $lookup:{
                        from:'categories',
                        let : {                           
                            catId : '$category_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$catId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    name:1,                                                                    
                                }
                            }
                        ],
                        as: 'cat_details'
                    }
                },
                {
                    $unwind: '$cat_details'
                },

                {                   
                    $match : { 'category_id' : new mongoose.Types.ObjectId('647d28172412fa1fc4a2d599') }                   
                }, 
                
                {                   
                    $match : { 'isStatus' : 'Active'}                   
                }, 

                {
                    $limit : 6
                },

                { 
                    $sort : { createdAt : -1 } 
                },

                {
                    $project:{
                        _id:1,
                        heading:1,
                        post:1,
                        image:1,
                        isStatus:1,
                        isDeleted:1,
                        createdAt:1,
                        'user_details.fullname':1,                       
                        'user_details.image':1,
                        'cat_details.name':1
                    }
                }
            ]);
            //console.log(fashionDetails);
            res.render('front/home', {
                title: 'Home',
                catDetails,banDetails,loginUser,fashionDetails,popularityDetails
            })
        } catch(err){
            throw err;
        }
    }
    
    async showContact(req, res){
        try{
            let loginUser ='';
            if(!_.isEmpty(req.user)) {
                loginUser = await registerModel.findOne({ _id : req.user.id });
            }
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            res.render('front/contact', {
                title: 'Contact Us',
                error:req.flash('error'),
                success:req.flash('success'),  
                catDetails,loginUser
            })
        } catch(err){
            throw err;
        }
    }
    
    async contact(req, res){
        try{
            let save_data = await contactModel.create(req.body);            
            if (!_.isEmpty(save_data) && save_data._id) {
                const dateTimeObject = new Date();
                await mailer.sendMail(process.env.EMAIL, req.body.email, 'ZenBlog .. Thank You for Contacting us !!!', `Hi ${req.body.name} We are reviewing Your Meassage and will be contacting you reagarding your Query.<br> Date : ${dateTimeObject.toDateString()} <br> Time : ${dateTimeObject.toTimeString()} <br> `);
                await mailer.sendMail(process.env.EMAIL, process.env.ADMIN_EMAIL, 'Query therough Contact Form..<br>', `Name : ${req.body.name} <br> Email: ${req.body.email} <br> subject: ${req.body.subject} <br> Message: ${req.body.message} <br> Date : ${dateTimeObject.toDateString()} <br> Time : ${dateTimeObject.toTimeString()} <br> `);
                req.flash('success' , 'Send Successfully. Check your mail.');
                res.redirect('/contact');
            } else {
                req.flash('error' , 'Something went wrong!!!');
                res.redirect('/contact');
            }
        } catch(err){
            throw err;
        }
    }

    async showFaqs(req, res){
        try{
            let loginUser = '';
            if(!_.isEmpty(req.user)) {
                loginUser = await registerModel.findOne({ _id : req.user.id });
            }
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            const faqDetails = await faqModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1})
            res.render('front/faqs', {
                title: 'Faqs',              
                catDetails,loginUser,faqDetails
            })
        } catch(err){
            throw err;
        }
    }
    
    async categoryPost(req, res){
        try{
            let loginUser ='';
            if(!_.isEmpty(req.user)) {
                loginUser = await registerModel.findOne({ _id : req.user.id });
            }
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            const categoryHeadingName = await catModel.findOne({ _id: req.params.id });
            const postDetails = await postModel.aggregate([
                {
                    $lookup:{
                        from:'user_registers',
                        let : {                           
                            userId : '$user_register_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$userId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    fullname:1,
                                    email:1,
                                    image:1                                   
                                }
                            }
                        ],
                        as: 'user_details'
                    }
                },
                {
                    $unwind: '$user_details'
                },
                {
                    $lookup:{
                        from:'categories',
                        let : {                           
                            catId : '$category_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$catId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    name:1,                                                                    
                                }
                            }
                        ],
                        as: 'cat_details'
                    }
                },
                {
                    $unwind: '$cat_details'
                },
                
                // {
                //     $match:{
                //         $expr:{
                //             $and:[
                //                 { 
                //                     $eq : [ '$category_id' , 'new mongoose.Types.ObjectId(req.params.id)'],
                //                     $eq : [ '$isStatus' , 'Active']
                //                 }
                                
                //             ]
                //         }
                //     }                   
                // },              
                {
                    $match : { 'category_id' : new mongoose.Types.ObjectId(req.params.id)}
                },

                {
                    $match : { 'isStatus' : 'Active' }
                },

                // {
                //     $match : { 'isDelete' : false }
                // },              
            
                {
                    $project:{
                        _id:1,
                        heading:1,
                        post:1,
                        image:1,
                        isStatus:1,
                        isDeleted:1,
                        createdAt:1,
                        'user_details.fullname':1,
                        'user_details.email':1,
                        'user_details.image':1,
                        'cat_details.name':1
                    }
                }
            ]);
            //console.log(postDetails); 
            res.render('front/categoryBlogPosts', {
                title: 'Category Posts',             
                catDetails,loginUser,postDetails,categoryHeadingName
            })
        } catch(err){
            throw err;
        }
    }

    async singlePost(req, res){
        try{
            let loginUser ='';
            if(!_.isEmpty(req.user)) {
                loginUser = await registerModel.findOne({ _id : req.user.id });
            }
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            const commentShowDetails = await commentModel.aggregate ([
                {
                    $lookup:{
                        from:'user_registers',
                        let : {                           
                            userId : '$user_register_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$userId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    fullname:1, 
                                    image:1                                                                                    
                                }
                            }
                        ],
                        as: 'user_details'
                    }
                },
                {
                    $unwind: '$user_details'
                },             
                
                {
                    $match : { 'post_id' : new mongoose.Types.ObjectId(req.params.id)}
                },

                {
                    $match : { 'isStatus' : 'Active' }
                },
            
                {
                    $project:{
                        _id:1,
                        message:1,
                        createdAt:1,                                         
                        'user_details.fullname':1,
                        'user_details.image':1,                         
                    }
                }
            ])
            const commentSaveDetails = await postModel.aggregate([
                {
                    $lookup:{
                        from:'user_registers',
                        let : {                           
                            userId : '$user_register_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$userId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    _id:1,
                                    fullname:1                                                                                     
                                }
                            }
                        ],
                        as: 'user_details'
                    }
                },
                {
                    $unwind: '$user_details'
                },             
                
                {
                    $match : { '_id' : new mongoose.Types.ObjectId(req.params.id)}
                },
            
                {
                    $project:{
                        _id:1,                                         
                        'user_details._id':1, 
                        'fullname._id':1,                     
                    }
                }
            ]);
            const OnePostDetails = await postModel.aggregate([
                {
                    $lookup:{
                        from:'user_registers',
                        let : {                           
                            userId : '$user_register_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$userId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    _id:1,
                                    fullname:1,
                                    email:1,
                                    image:1                                                               
                                }
                            }
                        ],
                        as: 'user_details'
                    }
                },
                {
                    $unwind: '$user_details'
                },
                {
                    $lookup:{
                        from:'categories',
                        let : {                           
                            catId : '$category_id'   
                        },
                        pipeline:[
                            {
                                $match:{
                                    $expr:{
                                        $and:[
                                            { $eq : [ '$_id' , '$$catId']}
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    name:1,                                                                    
                                }
                            }
                        ],
                        as: 'cat_details'
                    }
                },
                {
                    $unwind: '$cat_details'
                },
                
                {
                    $match : { '_id' : new mongoose.Types.ObjectId(req.params.id)}
                },

                
            
                {
                    $project:{
                        _id:1,
                        heading:1,
                        post:1,
                        image:1,
                        isStatus:1,
                        isDeleted:1,
                        createdAt:1,
                        'user_details._id':1,
                        'user_details.fullname':1,
                        'user_details.email':1,
                        'user_details.image':1,
                        'cat_details.name':1
                    }
                }
            ]);
            //console.log(commentShowDetails); 
            res.render('front/singlePost', {
                title: 'Single Post',             
                catDetails,loginUser,OnePostDetails,commentShowDetails,commentSaveDetails
            })
        } catch(err){
            throw err;
        }
    }

    
    async saveComment(req, res){
        try{
            const postId = req.body.post_id;
            let save_comm_data = await commentModel.create(req.body);            
            if (!_.isEmpty(save_comm_data) && save_comm_data._id) {              
                req.flash('success' , 'Comment saved successfully.');
                res.redirect(`/singlePost/${postId}`);
            } else {
                req.flash('error' , 'Something went wrong!!!');
                res.redirect(`/singlePost/${postId}`);
            }
            
        } catch(err){
            throw err;
        }
    }


    async showProfile(req, res){
        try{
            let loginUser ='';
            if(!_.isEmpty(req.user)) {
                loginUser = await registerModel.findOne({ _id : req.user.id });
            }
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            res.render('front/profile', {
                title: 'Profile',
                error:req.flash('error'),
                success:req.flash('success'),
                loginUser,catDetails
            })
        } catch(err){
            throw err;
        }
    }
    
    async updateProfile(req, res){
        try{         
            const existing_image = await registerModel.findOne({ email: req.body.email });
            req.body.fullname = `${req.body.fname} ${req.body.lname}`;
            const updated_obj = {
                fname: req.body.fname,
                lname: req.body.lname,
                fullname: req.body.fullname
            }

            if (!_.isEmpty(req.file)) { //console.log(req.file);     
                updated_obj.image = req.file.filename;                          
                fs.unlinkSync(`./public/admin/img/${existing_image.image}`);
            } else {                
            }

            //console.log(updated_obj);            
            let update_data = await registerModel.findByIdAndUpdate(req.body.userid, updated_obj);
            if (!_.isEmpty(update_data)) {
                req.flash('success','Profile details succesfully updated');
                res.redirect('/profile')                
            } else {
                req.flash('error','There was some error. Please try again');
                res.redirect('/profile')  
            }
        } catch(err){
            throw err;
        }
    } 
    
    async showChangePassword(req, res){
        try{
            let loginUser ='';
            if(!_.isEmpty(req.user)) {
                loginUser = await registerModel.findOne({ _id : req.user.id });
            }
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            res.render('front/changePassword', {
                title: 'Change Password',
                error:req.flash('error'),
                success:req.flash('success'),  
                catDetails,loginUser
            })
        } catch(err){
            throw err;
        }
    } 

    async updateChangePassword(req, res){
        try{
            let User = await registerModel.findOne({ _id : req.body.id }); 
            //console.log(req.body.id);        
            if(bcrypt.compareSync(req.body.oldPassword, User.password)){
                if(req.body.password != req.body.confirmPassword){
                    req.flash('error','Password not Matching');
                    return res.redirect('/changePassword');
                }
                if(req.body.password == req.body.oldPassword){
                    req.flash('error','New Password cannot be same as Old Password');
                    return res.redirect('/changePassword');
                }                
                req.body.password = bcrypt.hashSync(req.body.password , bcrypt.genSaltSync(10));                
                    let updated_obj = {       
                        password: req.body.password,
                    } 
                               
                let update_data = await registerModel.findByIdAndUpdate(req.body.id, updated_obj);
                if (!_.isEmpty(update_data)) {
                    req.flash('success','Password succesfully updated');
                    res.redirect('/changePassword')                
                } else {
                    req.flash('error','There was some error. Please try again');
                    res.redirect('/changePassword')  
                }
            }
        } catch(err){
            throw err;
        }
    }

    /* LogOut */  
    async logout(req, res) {
        try {
            res.clearCookie('front_user_token');
            res.redirect('/login');           
        } catch (err) {
            throw err;
        }
    }

}

module.exports = new HomeController();