const catModel = require("../../models/admin/category.model");
const banModel = require("../../models/admin/banner.model");
const registerModel = require('../../models/front/register.model');
const postModel = require('../../models/front/post.model');
const os = require('os'); const fs = require('fs');
const mongoose = require('mongoose');

class BlogController{

    async userAuth(req, res, next){
        try{
            if(!_.isEmpty(req.user)){                   
                next();
            } else { 
                req.flash('error' , 'UnAuthorized UseR .. Please Login')              
                res.redirect('/login');                           
            }

        }catch(err){
            throw(err);
        }
    }

    async showPost(req, res){
        try{
            
            let loginUser = await registerModel.findOne({ _id : req.user.id });           
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            res.render('front/post', {
                title: 'Blog Post',
                error:req.flash('error'),
                success:req.flash('success'),
                catDetails,loginUser                      
            })
        }catch(err){
            throw(err);
        }
    }

    async post(req, res){ 
        try{ 
            let is_exists_heading = await postModel.findOne({ heading: req.body.heading });
            if(!_.isEmpty(is_exists_heading)){
                req.flash('error','This heading already exists');
                return res.redirect('/post');
            }
            // if (!.has(req.body, 'person') || ((.has(req.body, 'person') && (.isUndefined(req.body.person)) || .isNull(req.body.person) || _.isEmpty(req.body.person.trim())))) {
               
            // }
            
            if (!_.isEmpty(req.file)) {
                req.body.image = req.file.filename;
            } else {
                req.flash('error' , 'Image must be Added');
                return res.redirect('/post');
            }

            let save_data = await postModel.create(req.body);           
            if (!_.isEmpty(save_data) && save_data._id) {
                req.flash('success' , 'Blog Added Successfully. Wait for Admin approval');
                res.redirect('/post');
            } else {
                req.flash('error' , 'Something went wrong');
                res.redirect('/post');
            }
           
        } catch(err){
            throw err;
        }
    } 
    
    async showBlog(req, res, next){ 
        try{
            //aggreagation on post pending
            let loginUser = await registerModel.findOne({ _id : req.user.id });           
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            //const banDetails = await banModel.find({ isDeleted: false, isStatus: 'Active' });
            //const postDetails = await postModel.find({ isDeleted: false, user_register_id :{$eq : req.user.id } });
            const postDetails = await postModel.aggregate([                
                {                   
                    $lookup:{ //post model
                        from: 'categories',
                        let : {                           
                            catId : '$category_id'    
                        },
                        pipeline: [ //category model
                            {
                                $match: {
                                    $expr: {
                                        $and: [
                                            { $eq: [ '$_id', '$$catId' ] }                                            
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    _id:1,
                                    name:1,                                   
                                }
                            }
                        ],
                        as: 'category_details'                                   
                    } 
                },
                {
                    $unwind: '$category_details' 
                },
                { //post model
                   $match : { 'user_register_id' : new mongoose.Types.ObjectId(req.user.id) }                                                     
                },               
                {
                    $project: {
                        heading:1,
                        post:1,
                        image:1,
                        isStatus:1,
                        isDeleted:1,   
                        user_register_id:1,
                        createdAt:1,
                        'category_details.name':1,
                        'category_details._id':1                                                                                       
                    }
                }                
            ])   

            console.log(postDetails); 
            res.render('front/myblog', {
                title: 'My Blog Posts',
                error:req.flash('error'),
                success:req.flash('success'),
                catDetails,loginUser,postDetails                      
            })
        }catch(err){
            throw(err);
        }
    } 

    async viewPost(req, res, next){
        try{
            
            let loginUser = await registerModel.findOne({ _id : req.user.id });           
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            const postDetails = await postModel.findOne({ _id : req.params.id });   
            res.render('front/viewPost', {
                title: 'Blog Post',               
                catDetails,loginUser,postDetails                      
            })
        }catch(err){
            throw(err);
        }
    }

    async showEditPost(req, res, next){
        try{
            
            let loginUser = await registerModel.findOne({ _id : req.user.id });           
            const catDetails = await catModel.find({ isDeleted: false, isStatus: 'Active' }).sort({ createdAt: -1});
            const postDetails = await postModel.aggregate([                
                {                   
                    $lookup:{
                        from: 'categories',
                        let : {                           
                            catId : '$category_id'   
                        },
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $and: [
                                            { $eq: [ '$_id', '$$catId' ] }                                            
                                        ]
                                    }
                                }
                            },
                            {
                                $project:{
                                    _id:1,
                                    name:1,                                   
                                }
                            }
                        ],
                        as: 'category_details'                                   
                    } 
                },
                {
                    $unwind: '$category_details'
                },
                {
                   $match: { '_id' : new mongoose.Types.ObjectId(req.params.id) }                  
                }
                ,{
                    $project: {
                        heading:1,
                        post:1,
                        image:1,
                        isStatus:1,   
                        user_register_id:1,
                        createdAt:1,
                        'category_details.name':1,
                        'category_details._id':1                                                                                       
                    }
                }                
            ])   

            res.render('front/editPost', {
                title: 'Blog Post',
                error:req.flash('error'),
                success:req.flash('success'),
                catDetails,loginUser,postDetails                      
            })
        }catch(err){
            throw(err);
        }
    }

    async updatePost(req, res){ 
        try{
            let existingIamge = await postModel.findOne({ _id: req.body.id }); 
            let is_exists_heading = await postModel.findOne({ heading: req.body.heading , _id: { $ne: req.body.id } });
            if(!_.isEmpty(is_exists_heading)){
                req.flash('error','This heading already exists');
                return res.redirect(`/editPost/${req.body.id}`);
            } 
            
            const updated_obj = {
                heading: req.body.heading,
                post: req.body.post                
            }
            
            if (!_.isEmpty(req.file)) {
                fs.unlinkSync(`./public/front/blog-img/${existingIamge.image}`);               
                updated_obj.image = req.file.filename;
            } else {               
            }

            //console.log("dasdasdad10");
            let update_data = await postModel.findByIdAndUpdate(req.body.id, updated_obj);          
            if (!_.isEmpty(update_data) && update_data._id) {
                req.flash('success' , 'Blog Updated Successfully');
                return res.redirect('/myblogs');
            } else {
                req.flash('error' , 'Something went wrong');
                return res.redirect('/myblogs');
            }
           
        } catch(err){
            throw err;
        }
    }

    async deletePost(req, res, next){
        try{            
            let current_image = await postModel.findOne({ _id: req.params.id });          
            let updated_obj = {
                isDeleted: true
            }
            fs.unlinkSync(`./public/front/blog-img/${current_image.image}`);
            let deleted_data = await postModel.findByIdAndUpdate(req.params.id, updated_obj);
            if (deleted_data) {
                req.flash('success' , 'Successfully Deleted');
                res.redirect('/myblogs')
            }
        }catch(err){
            throw(err);
        }
    }


}

module.exports = new BlogController();