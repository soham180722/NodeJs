
class AppController {

    async welcome(req,res){
        try{ 
            // https://api.openweathermap.org/data/2.5/weather?q=kolkata&appid=d4421cc788f98569a95558e7105bfb9e        
            const data = 0;
            res.render('welcome',{
               title: 'Welcome',
               wdata: data
            })
        } catch(err){
            throw err;
        }
 
    }    
    async cityInput(req,res){
        try{
            const city = req.body.city;            
            const apikey = 'd4421cc788f98569a95558e7105bfb9e';
            const apiurl = 'https://api.openweathermap.org/data/2.5/weather?units=metric&q=';
            const response = await fetch(apiurl + city + `&appid=${apikey}`); 
            let data = await response.json();
            console.log(data);           
            res.render('welcome',{
               title: 'Welcome',
               wdata: data
            })
        } catch(err){
            throw err;
        }
 
    }
}

module.exports = new AppController();