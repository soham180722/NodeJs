const router = require('express').Router();
const Controller = require('../controllers/app.controller');


router.get('/', Controller.welcome);
router.post('/getWeather', Controller.cityInput);


module.exports = router;