const express = require('express');
const app = express();
require('dotenv').config();
const path = require('path');
const bodyParser = require('body-parser');


app.set('view engine','ejs');
app.set('views','views');

app.use(express.static(path.join(__dirname,'public')));

app.use(bodyParser.urlencoded({
    extended:true
}))

const AppRouter = require('./routes/app.route');
app.use(AppRouter);

app.listen(process.env.PORT , () => {
    console.log(`server is running @ http://127.0.0.1:${process.env.PORT}`);
})